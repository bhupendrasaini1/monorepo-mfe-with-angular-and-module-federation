declare module 'bookMfe/Module';
declare module 'authMfe/Module';